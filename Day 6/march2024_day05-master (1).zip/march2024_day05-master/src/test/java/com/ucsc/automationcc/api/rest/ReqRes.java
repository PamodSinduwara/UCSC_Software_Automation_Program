package com.ucsc.automationcc.api.rest;

import static io.restassured.RestAssured.given;

import static io.restassured.RestAssured.baseURI;

import static org.hamcrest.Matchers.equalTo;

import io.restassured.http.ContentType;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class ReqRes {

    @BeforeTest
    public void initBaseURI(){
        baseURI = "https://reqres.in/api/";
    }

    @Test
    public void getUsers(){
        given()
                .when()
                .get("users?page=1")
                .then()
                .statusCode(200)
                .log().all()
                ;
    }

    @Test
    public void createUser(){
        String body = "{\n" +
                "    \"name\": \"morpheus\",\n" +
                "    \"job\": \"leader\"\n" +
                "}";
        given()
                .contentType(ContentType.JSON)
                .body(body)
                .when()
                .post("users")
                .then()
                .statusCode(201)
                .assertThat()
                .body("name", equalTo("morpheus"))
                .log().all();
    }
}
