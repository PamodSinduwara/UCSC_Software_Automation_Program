package com.ucsc.automationcc.pom.uicomponents;

import com.ucsc.automationcc.pom.pages.PageMobileResults;
import com.ucsc.automationcc.pom.pages.PagePartyDressResults;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import java.util.HashMap;
import java.util.Map;

public class SearchComponent {

    WebDriver driver;

    String visibleText;

    Map<String, Object> searchMap = new HashMap<>();

    {
        searchMap.put("Cell Phones & Accessories", PageMobileResults.class);
        searchMap.put("Clothing, Shoes & Accessories", PagePartyDressResults.class);
    }
    @FindBy(xpath = "//input[@id='gh-ac']")
    public WebElement searchField;

    @FindBy(xpath = "//select[@id='gh-cat']")
    public WebElement categorySelector;

    @FindBy(xpath = "//input[@id='gh-btn']")
    public WebElement searchButton;

    public SearchComponent(WebDriver driver){
        this.driver = driver;
    }

//    public SearchComponent getSearchComponent(){
//        return PageFactory.initElements(driver, SearchComponent.class);
//    }

    public void typeOnSearchField(String typingValue){
        searchField.sendKeys(typingValue);
    }

    public void selectValueInCategorySelector(String visibleText){
        this.visibleText = visibleText;
        new Select(categorySelector).selectByVisibleText(visibleText);
    }

    public <T> T clickOnSearchButton(){
        searchButton.click();
//        if(visibleText.equalsIgnoreCase("Cell Phones & Accessories")){
//            return PageFactory.initElements(driver, (Class<T>) PageMobileResults.class);
//        } else if (visibleText.equalsIgnoreCase("Clothing, Shoes & Accessories")) {
//            return PageFactory.initElements(driver, (Class<T>) PagePartyDressResults.class);
//        }
//        return null;
        return PageFactory.initElements(driver, (Class<T>) searchMap.get(visibleText));
    }
}
