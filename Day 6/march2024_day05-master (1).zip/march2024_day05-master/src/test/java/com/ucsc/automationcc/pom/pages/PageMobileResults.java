package com.ucsc.automationcc.pom.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;

public class PageMobileResults extends PageBase{

    @FindBy(xpath = "//span[text()='Apple']")
    public WebElement appleCheckBox;

    public PageMobileResults(WebDriver driver) {
        super(driver);
    }

//    public void scrollByPixel(int x, int y){
//        new Actions(driver).scrollByAmount(x, y).perform();
//    }

    public void tickTheAppleCheckBox(){
        appleCheckBox.click();
    }
}
