package com.ucsc.automationcc.pom.pages;

import com.ucsc.automationcc.pom.uicomponents.SearchComponent;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class PageEbayHome extends PageBase{

//    @FindBy(xpath = "//input[@id='gh-ac']")
//    public WebElement searchField;
//
//    @FindBy(xpath = "//select[@id='gh-cat']")
//    public WebElement categorySelector;
//
//    @FindBy(xpath = "//input[@id='gh-btn']")
//    public WebElement searchButton;

    SearchComponent searchComponent;

    public PageEbayHome(WebDriver driver){
        super(driver);

    }

    public SearchComponent getSearchComponent(){
        if(searchComponent == null){
            searchComponent = PageFactory.initElements(driver, SearchComponent.class);
        }
        return searchComponent;
    }

//    public void typeOnSearchField(String typingValue){
//        searchField.sendKeys(typingValue);
//    }
//
//    public void selectValueInCategorySelector(String visibleText){
//        new Select(categorySelector).selectByVisibleText(visibleText);
//    }
//
//    public PageMobileResults clickOnSearchButton(){
//        searchButton.click();
//        return PageFactory.initElements(driver, PageMobileResults.class);
//    }
}
