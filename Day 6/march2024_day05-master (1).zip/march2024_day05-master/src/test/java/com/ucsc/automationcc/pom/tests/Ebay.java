package com.ucsc.automationcc.pom.tests;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.ucsc.automationcc.pom.pages.PageBase;
import com.ucsc.automationcc.pom.pages.PageEbayHome;
import com.ucsc.automationcc.pom.pages.PageMobileResults;
import com.ucsc.automationcc.pom.pages.PagePartyDressResults;
import com.ucsc.automationcc.pom.utils.TestNGUtils;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

public class Ebay extends TestNGUtils {

    @Test
    public void mobileSearch(){
        ExtentTest extentTest = extent.createTest("mobileSearch");
        extentTest.assignAuthor("Sanath")
                        .assignDevice(System.getProperty("browser"))
                                .assignCategory("Regression");
        extentTest.log(Status.INFO, "start mobile search");
//        PageBase pageBase = PageFactory.initElements(driver, PageBase.class);
        PageBase pageBase = PageFactory.initElements(browserFactory.getDriver(), PageBase.class);
        PageEbayHome pageEbayHome = pageBase.initApplication();
        pageEbayHome.getSearchComponent().typeOnSearchField("mobile phone");
        pageEbayHome.getSearchComponent().selectValueInCategorySelector
                ("Cell Phones & Accessories");
        PageMobileResults pageMobileResults = pageEbayHome.getSearchComponent().clickOnSearchButton();
        pageMobileResults.scrollByPixel(0, 400);
        pageMobileResults.tickTheAppleCheckBox();
        extentTest.pass("mobile Search is passed");
    }

    @Test
    public void partyDressSearch(){
        ExtentTest extentTest = extent.createTest("partyDressSearch");
        extentTest.assignAuthor("Ishari")
                .assignDevice(System.getProperty("browser"))
                .assignCategory("Regression");
        extentTest.log(Status.INFO, "start party dress search");
//        PageBase pageBase = PageFactory.initElements(driver, PageBase.class);
        PageBase pageBase = PageFactory.initElements(browserFactory.getDriver(), PageBase.class);
        PageEbayHome pageEbayHome = pageBase.initApplication();
        pageEbayHome.getSearchComponent().typeOnSearchField("party dress");
        pageEbayHome.getSearchComponent().selectValueInCategorySelector
                ("Clothing, Shoes & Accessories");
        PagePartyDressResults pagePartyDressSearch = pageEbayHome.getSearchComponent().clickOnSearchButton();
        pagePartyDressSearch.scrollByPixel(0, 400);
        pagePartyDressSearch.tickTheWeddingCheckBox();
        extentTest.pass("Party dress Search is passed");
    }
}
