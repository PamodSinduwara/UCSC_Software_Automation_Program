package com.ucsc.automationcc.pom.utils;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BrowserFactory {

    static BrowserFactory browserFactory;

    ThreadLocal<WebDriver> tlWebDriver = ThreadLocal.withInitial(() -> {
        WebDriver webDriver;
        String browser = System.getProperty("browser", "chrome");
        switch (browser){
            case "chrome":
                webDriver = WebDriverManager.chromedriver().create();
                break;
            case "firefox":
                webDriver = WebDriverManager.firefoxdriver().create();
                break;
            case "edge":
                webDriver = WebDriverManager.edgedriver().create();
                break;
            default:
                throw new RuntimeException("Undefined browser type");
        }

        webDriver.manage().window().maximize();
        return webDriver;
    });

    private BrowserFactory(){

    }

    public static BrowserFactory getBrowserFactory(){
        if(browserFactory == null){
            browserFactory = new BrowserFactory();
        }
        return browserFactory;
    }

    public WebDriver getDriver(){
        return tlWebDriver.get();
    }

    public void quitDriver(){
        tlWebDriver.get().quit();
    }
}
